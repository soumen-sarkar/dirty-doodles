jQuery(window).load(function(){
	//Background Image carousel
	$('.carousel').carousel({
		//interval: 7000
	})
});